<?php
defined('_JEXEC') or die;

if (!$lineone)
{
	return;
}
?>
<div class="footerghsvs mod_footerghsvs" aria-label="Copyright">
	<?php echo $lineone; ?>
</div>
