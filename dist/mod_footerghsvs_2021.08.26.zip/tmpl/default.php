<?php
defined('_JEXEC') or die;

if (!$lineone)
{
	return;
}
?>
<div class="footerghsvs" aria-label="Copyright">
	<?php echo $lineone; ?>
</div>
